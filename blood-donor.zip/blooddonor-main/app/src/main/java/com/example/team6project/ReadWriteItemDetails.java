package com.example.team6project;

public class ReadWriteItemDetails {
    public   String name,age,gender,mobile,bloodGroup,hospitalAddress;

    public ReadWriteItemDetails(String name, String age, String gender, String mobile, String bloodGroup, String hospitalAddress) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.mobile = mobile;
        this.bloodGroup = bloodGroup;
        this.hospitalAddress = hospitalAddress;
    }

    public ReadWriteItemDetails(){

    }
}

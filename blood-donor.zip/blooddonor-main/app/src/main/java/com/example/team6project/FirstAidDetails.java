package com.example.team6project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirstAidDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid_details);
    }
}